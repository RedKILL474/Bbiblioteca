package org.example.biblioteca;

public class Main {
    public static void main(String[] args) {

        MaterialBiblioteca[] materiales = new MaterialBiblioteca[3];

        materiales[0] = new Libro("Cien Años de Soledad", "Gabriel García Márquez", 1967, "Realismo Mágico");
        materiales[1] = new Revista("National Geographic", "Varios Autores", 2023, 150);
        materiales[2] = new Tesis("Implementación de IA en Salud", "Juan Pérez", 2024, "Universidad Nacional");

        System.out.println("=== Catálogo de la Biblioteca ===");
        

        for (MaterialBiblioteca material : materiales) {
            material.mostrarInfo();
        }
    }
}
